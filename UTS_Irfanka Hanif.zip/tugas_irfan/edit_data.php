<?php
require 'functions.php';
if( !isset($_SESSION["login"]) ) {
    header("Location: login.php");
    exit;
}
$id = $_GET['id'];
// query data mahasiswa berdasarkan id
$informasi = query("SELECT * FROM tbl_informasi WHERE id = $id")[0];

// Check if form is submitted and if 'id' parameter is set in the URL
if (!empty($_POST) && isset($_GET['id'])) {

    // Check if the form update is successful
    if (edit($_POST) > 0) {
        echo "
            <script>
                alert('Data berhasil diedit!');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Data gagal diedit!');
                document.location.href = 'index.php';
            </script>
        ";
    }
}
?>

<div class="row mt-2">
    <!-- Form for editing data -->
<form id="formEditData" action="" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="id" value="<?= $informasi["id"]; ?>">
	<input type="hidden" name="gambarLama" value="<?= $informasi["gambar"]; ?>">
    <!-- Judul Field -->
    <div class="mb-3">
        <label for="judul" class="form-label">Judul:</label>
        <input type="text" id="judul" name="judul" class="form-control" value="<?= $informasi['judul'] ?? ''; ?>" required>
        <div class="invalid-feedback">Judul tidak boleh kosong.</div>
    </div>

    <!-- Deskripsi Field -->
    <div class="mb-3">
        <label for="deskripsi" class="form-label">Deskripsi:</label>
        <textarea id="deskripsi" name="deskripsi" class="form-control" rows="3" required><?= $informasi['deskripsi'] ?? ''; ?></textarea>
        <div class="invalid-feedback">Deskripsi tidak boleh kosong.</div>
    </div>

    <!-- Alamat Field -->
    <div class="mb-3">
        <label for="alamat" class="form-label">Alamat:</label>
        <input type="text" id="alamat" name="alamat" class="form-control" value="<?= $informasi['alamat'] ?? ''; ?>" required>
        <div class="invalid-feedback">Alamat tidak boleh kosong.</div>
    </div>

    <!-- Telepon Field -->
    <div class="mb-3">
        <label for="telepon" class="form-label">Telepon:</label>
        <input type="tel" id="telepon" name="telepon" class="form-control" pattern="[0-9]{10,15}" value="<?= $informasi['telepon'] ?? ''; ?>" required>
        <div class="invalid-feedback">Nomor telepon tidak valid.</div>
    </div>

    <!-- Gambar Field -->
    <div class="mb-3">
		
        <label for="gambar" class="form-label">Gambar:</label><br>
		<img src="img/<?= $informasi['gambar']; ?>" width="200"> <br><br>
        <input type="file" id="gambar" name="gambar" class="form-control">
    </div>

    <!-- Submit and Back Buttons -->
    <button type="submit" id="tambah" class="btn btn-success">Edit Data</button>
    <a href="index.php" class="btn btn-danger">Kembali</a>
</form>
</div>
