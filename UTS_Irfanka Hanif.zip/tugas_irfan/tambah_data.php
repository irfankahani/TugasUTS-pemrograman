<?php
require 'functions.php';
if( !isset($_SESSION["login"]) ) {
    header("Location: login.php");
    exit;
}
// Check if the form is submitted
if (!empty($_POST)) {
    // Call the 'tambah' function to add data and check if it's successful
    if (tambah($_POST) >= 0) {
        echo "
            <script>
                alert('Data berhasil ditambahkan!');
                document.location.href = 'index.php';
            </script>
        ";
    } else {
        echo "
            <script>
                alert('Data gagal ditambahkan!');
                document.location.href = 'index.php';
            </script>
        ";
    }
}

?>

<div class="row mt-2">
    <!-- Form for adding new data -->
<form id="formTambahData" action="" method="POST" enctype="multipart/form-data">
    <!-- Judul Field -->
    <div class="mb-3">
        <label for="judul" class="form-label">Judul:</label>
        <input type="text" id="judul" name="judul" class="form-control">
        <div class="invalid-feedback">Judul tidak boleh kosong.</div>
    </div>
    
    <!-- Deskripsi Field -->
    <div class="mb-3">
        <label for="deskripsi" class="form-label">Deskripsi:</label>
        <textarea id="deskripsi" name="deskripsi" class="form-control" rows="3"></textarea>
        <div class="invalid-feedback">Deskripsi tidak boleh kosong.</div>
    </div>
    
    <!-- Alamat Field -->
    <div class="mb-3">
        <label for="alamat" class="form-label">Alamat:</label>
        <input type="text" id="alamat" name="alamat" class="form-control">
        <div class="invalid-feedback">Alamat tidak boleh kosong.</div>
    </div>
    
    <!-- Telepon Field -->
    <div class="mb-3">
        <label for="telepon" class="form-label">Telepon:</label>
        <input type="tel" id="telepon" name="telepon" class="form-control" pattern="[0-9]{10,15}">
        <div class="invalid-feedback">Nomor telepon tidak valid.</div>
    </div>
    
    <!-- Gambar Field -->
    <div class="mb-3">
        <label for="gambar" class="form-label">Gambar:</label>
        <input type="file" id="gambar" name="gambar" class="form-control" accept="image/*">
    </div>
    
    <!-- Submit and Back Buttons -->
    <button type="submit" id="tambah" class="btn btn-success">Tambah Data</button>
    <a href="index.php" class="btn btn-danger">Kembali</a>
</form>

</div>