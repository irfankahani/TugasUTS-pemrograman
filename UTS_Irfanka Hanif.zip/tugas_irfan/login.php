<?php 
session_start();
require 'functions.php';


if( isset($_SESSION["login"]) ) {
	header("Location: index.php");
	exit;
}


if( !empty($_POST) ) {
    // var_dump($_POST);
	$email      = $_POST["email"];
	$password   = $_POST["password"];

	$result = mysqli_query($conn, "SELECT * FROM tbl_user WHERE email = '$email'");

    
	// cek username
	if( mysqli_num_rows($result) === 1 ) {

		// cek password
		$row = mysqli_fetch_assoc($result);
        
		if( password_verify($password, $row["password"]) ) {
			// set session
			$_SESSION["login"] = true;

			header("Location: index.php");
			exit;

		}
	}

	$error = true;

}


?>
<!doctype html>
<html lang="en">
  <head>
    <!-- meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3 CSS (Stable version) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
      /* Body Background */
      body {
        /* background: linear-gradient(90deg, #00d4ff, #0062cc); */
        background-image: url('bg-image.png');
      }

      /* Form Card Styling */
      .card {
        background-color: #ffffff; /* White for card background */
        border-radius: 15px;
        box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
      }

      /* Card Header Styling */
      .card-header {
        background-color: #343a40 !important;
        color: #fff;
        border-radius: 15px 15px 0 0;
      }

      /* Input Valid/Invalid Feedback */
      .is-valid {
        border-color: #28a745; /* Green */
      }

      .is-invalid {
        border-color: #dc3545; /* Red */
      }

      .valid-feedback,
      .invalid-feedback {
        display: none;
      }

      .is-valid + .valid-feedback {
        display: block;
      }

      .is-invalid + .invalid-feedback {
        display: block;
      }

      /* Button Styling */
      .btn-danger {
        background-color: #dc3545; /* Red button for login */
      }

      .btn-success {
        background-color: #28a745; /* Green button for registration */
      }

      /* Hover Effects */
      .btn-danger:hover {
        background-color: #c82333;
      }

      .btn-success:hover {
        background-color: #218838;
      }
    </style>
    <title>Halaman Registrasi</title>
  </head>
  <body>
    <div class="container">
        <div class="row justify-content-center mt-5 mb-5">
            
            <div class="card shadow-lg col-md-6 p-4">
            <?php if( isset($error) ) : ?>
              <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Alert!</strong> Email / Password Salah !!!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            <?php endif; ?>

                <div class="card-header bg-primary text-white text-center rounded-3">
                    <h4>Halaman Login</h4>
                </div>
                <div class="card-body">
                    <form method="post" id="login">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Input email ...">
                            <div class="invalid-feedback">Email tidak boleh kosong!</div>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Input password ...">
                            <div class="invalid-feedback">Password tidak boleh kosong!</div>
                        </div>
                        <div class="mb-3 text-center">
                            <button type="button" id="btn-registrasi" name="registrasi" class="btn btn-danger">Registrasi</button>
                            <button type="submit" name="login" class="btn btn-success" id="btn-login">Login</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3 JS (Stable version) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0Xz5JdMGFZmDk6fXli5OUhDi6mT3gFUpjwV4yVgQnybm2SQQ" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
            // Apply real-time validation on input fields
            $(' #email, #password').on('input', function() {
                validateInput($(this));
            });

            // Validation function
            function validateInput(input) {
                if (input.val() === '') {
                    input.removeClass('is-valid').addClass('is-invalid');
                } else {
                    input.removeClass('is-invalid').addClass('is-valid');
                }
            }

            $('#login').submit(function(e) {
                e.preventDefault(); // Prevent form submission to handle validation

                let isValid = true;

                // Validate all fields before submitting
                $(' #email, #password').each(function() {
                    if ($(this).val() === '') {
                        $(this).removeClass('is-valid').addClass('is-invalid');
                        isValid = false;
                    }
                });

                if (isValid) {
                    this.submit(); 
                }
            });

            $('#btn-registrasi').click(function(){
                window.location.href = 'registrasi.php';
            });
        });
    </script>
  </body>
</html>
