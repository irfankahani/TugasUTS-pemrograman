<?php
require 'functions.php';
// var_dump($_POST);
if (!empty($_POST)) {
    // Panggil fungsi registrasi dan kirim data POST
    if (registrasi($_POST) > 0) {
        echo "<script>
                alert('Anda berhasil melakukan registrasi!');
                window.location.href = 'login.php'; // Redirect ke halaman login
              </script>";
    } else {
        echo "<script>
                alert('Registrasi gagal! Silakan coba lagi.');
                window.location.href = 'register.php'; // Redirect kembali ke halaman registrasi
              </script>";
    }
}
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5.3 CSS (Stable version) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <style>
      /* Body Background */
      body {
        background-image: url('bg-image.png');
      }

      /* Form Card Styling */
      .card {
        background-color: #ffffff; /* White for card background */
        border-radius: 15px;
        box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
      }

      /* Card Header Styling */
      .card-header {
        background-color: #343a40 !important;
        color: #fff;
        border-radius: 15px 15px 0 0;
      }

      /* Input Valid/Invalid Feedback */
      .is-valid {
        border-color: #28a745; /* Green */
      }

      .is-invalid {
        border-color: #dc3545; /* Red */
      }

      .valid-feedback,
      .invalid-feedback {
        display: none;
      }

      .is-valid + .valid-feedback {
        display: block;
      }

      .is-invalid + .invalid-feedback {
        display: block;
      }

      /* Button Styling */
      .btn-danger {
        background-color: #dc3545; /* Red button for login */
      }

      .btn-success {
        background-color: #28a745; /* Green button for registration */
      }

      /* Hover Effects */
      .btn-danger:hover {
        background-color: #c82333;
      }

      .btn-success:hover {
        background-color: #218838;
      }
    </style>
    <title>Halaman Registrasi</title>
  </head>
  <body>
    <div class="container">
        <div class="row justify-content-center mt-5 mb-5">
            <div class="card shadow-lg col-md-6 p-4">
                <div class="card-header bg-primary text-white text-center rounded-3">
                    <h4>Halaman Registrasi</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="" id="regist">
                        <div class="mb-3">
                            <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Input nama lengkap ...">
                            <div class="invalid-feedback">Nama lengkap tidak boleh kosong!</div>
                        </div>
                        <div class="mb-3">
                            <label for="jk" class="form-label">Jenis Kelamin</label>
                            <select id="jk" class="form-select" name="jk">
                                <option value="">--Pilih--</option>
                                <option value="L">Laki-laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                            <div class="invalid-feedback">Pilih jenis kelamin!</div>
                        </div>
                        <div class="mb-3">
                            <label for="alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="alamat" name="alamat" rows="3" placeholder="Input alamat ..."></textarea>
                            <div class="invalid-feedback">Alamat tidak boleh kosong!</div>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Input email ...">
                            <div class="invalid-feedback">Email tidak boleh kosong!</div>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Input password ...">
                            <div class="invalid-feedback">Password tidak boleh kosong!</div>
                        </div>
                        <div class="mb-3 text-center">
                            <button type="button" class="btn btn-danger" id="btn-login">Login</button>
                            <button type="submit" name="register" class="btn btn-success">Registrasi</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3 JS (Stable version) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0Xz5JdMGFZmDk6fXli5OUhDi6mT3gFUpjwV4yVgQnybm2SQQ" crossorigin="anonymous"></script>

    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <script>
        $(document).ready(function() {
            // Apply real-time validation on input fields
            $('#nama_lengkap, #jk, #alamat, #email, #password').on('input', function() {
                validateInput($(this));
            });

            // Validation function
            function validateInput(input) {
                if (input.val() === '') {
                    input.removeClass('is-valid').addClass('is-invalid');
                } else {
                    input.removeClass('is-invalid').addClass('is-valid');
                }
            }

            $('#regist').submit(function(e) {
                e.preventDefault(); // Prevent form submission to handle validation

                let isValid = true;

                // Validate all fields before submitting
                $('#nama_lengkap, #jk, #alamat, #email, #password').each(function() {
                    if ($(this).val() === '') {
                        $(this).removeClass('is-valid').addClass('is-invalid');
                        isValid = false;
                    }
                });

                if (isValid) {
                    this.submit(); 
                }
            });

            $('#btn-login').click(function(){
                window.location.href = 'login.php';
            });
        });
    </script>
  </body>
</html>
