<?php 
// Start the session
session_start();

// Check if the user is logged in, redirect to login page if not
if( !isset($_SESSION["login"]) ) {
    header("Location: login.php");
    exit;
}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Halaman Utama</title>

    <!-- Custom Styles -->
    <style>
      body {
        font-family: 'Arial', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        min-height: 100vh;
      }

      /* Navbar Styling */
      .navbar {
        background-color: #343a40 !important;
      }

      .navbar .nav-link {
        color: #ffffff !important;
        margin-right: 15px;
      }

      .navbar .nav-link:hover {
        color: #00d4ff !important;
      }

      /* Hero Section Styling */
      .hero {
        text-align: center;
        color: white;
        background: linear-gradient(90deg, #00d4ff, #0062cc);
        padding: 100px 20px;
        flex-grow: 1;
      }

      .hero h1 {
        font-size: 3rem;
        margin-bottom: 20px;
      }

      .hero p {
        font-size: 1.2rem;
        margin-bottom: 30px;
      }

      /* Content Section */
      .content {
        background-color: #343a40;
        color: white;
      }

      /* Footer Styling */
      footer {
        background-color: #343a40;
        color: #ffffff;
        text-align: center;
        padding: 15px 0;
        width: 100%;
        margin-top: auto;
      }

      /* Card Styling */
      .card {
        margin-bottom: 20px;
      }

      /* Input Validation Styling */
      .is-valid {
        border-color: #28a745; /* Green */
      }

      .is-invalid {
        border-color: #dc3545; /* Red */
      }

      .valid-feedback,
      .invalid-feedback {
        display: none;
      }

      .is-valid + .valid-feedback {
        display: block;
      }

      .is-invalid + .invalid-feedback {
        display: block;
      }
    </style>
  </head>

  <body>
    <!-- Navbar Section -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
      <div class="container">
        <!-- <a class="navbar-brand" href="#">Logo</a> -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
          <div class="navbar-nav ms-auto">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
            <a class="nav-link" href="#informasi">Informasi Perusahaan</a>
            <a class="nav-link btn btn-outline-light" href="logout.php">Logout</a>
          </div>
        </div>
      </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero mt-5">
      <h1>Selamat <span style="color: #343a40 !important;text-shadow: 2px 2px 2px white;">Datang </span>di Halaman Utama</h1>
      <p style="color: #343a40 !important;text-shadow: 2px 1px 2px white;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque veniam dolore et. Corrupti unde doloribus expedita inventore praesentium quae fugit illum ratione provident optio, reiciendis deleniti omnis perferendis ducimus voluptatem.</p>
    </div>

    <!-- Content Section -->
    <div class="container mt-5">
      <div class="row content p-3 text-center" id="informasi">
        <!-- Display page content dynamically based on URL parameter -->
        <?php if(isset($_GET['page'])){ ?>
            <?php switch ($_GET['page']) {
                case 'tambah':
                    echo "<h4>Tambah Informasi Perusahaan</h4>";
                    break;
                case 'edit':
                    echo "<h4>Edit Informasi Perusahaan</h4>";
                    break;
                case 'detail':
                    echo "<h4>Detail Informasi Perusahaan</h4>";
                    break;
            } ?>
        <?php } else { ?>
            <h4>Daftar Informasi Perusahaan</h4>
        <?php } ?>
      </div>

      <?php if(!isset($_GET['page'])){
        echo '
            <div class="row mb-4 mt-2">
              <div class="col text-end">
                <a href="index.php?page=tambah" class="btn btn-success btn-sm">
                  Tambah Data
                </a>
              </div>
            </div>';
      }
      ?>

      <div class="row mb-5">
        <!-- Dynamic content based on page parameter -->
        <?php if(isset($_GET['page'])) { 
            $page = $_GET['page'];
            switch ($page) {
                case 'tambah':
                    include 'tambah_data.php';
                    break;
                case 'edit':
                    if(isset($_GET['id'])){
                      include 'edit_data.php';
                    }else{
                      header('location:index.php');
                    }
                    break;
                case 'detail':
                    if(isset($_GET['id'])){
                      include 'detail_data.php';
                    }else{
                      header('location:index.php');
                    }
                    break;
                default:
                    break;
            }
        } else { ?>
            <!-- Displaying data from the database -->
            <?php
                require 'functions.php';
                $page = (isset($_GET['pages']))? $_GET['pages'] : 1;
                $limit = 8; 
                $limit_start = ($page - 1) * $limit;
                $no = $limit_start + 1;

                $data = query("SELECT * FROM tbl_informasi ORDER BY id ASC LIMIT $limit_start, $limit");
                $count_data = query("SELECT count(*) AS jumlah FROM tbl_informasi");
                if($data){
            ?>
            <?php foreach( $data as $row ) : ?>
                <div class="col-md-4 col-sm-12 mb-4">
                    <img src="img/<?= $row['gambar']; ?>" class="card-img-top mt-2" style="min-width:100%;min-height:200px;max-height:200px;" alt="...">
                    <div class="card-body text-center">
                        <h5 class="card-title"><?=$row['judul'];?></h5>
                        <a href="index.php?page=edit&id=<?=$row['id'];?>" class="btn btn-primary">Edit</a>
                        <a href="index.php?page=detail&id=<?=$row['id'];?>" class="btn btn-warning">detail</a>
                        <a href="hapus.php?id=<?= $row["id"]; ?>" class="btn btn-danger">hapus</a>
                    </div>
                </div>
                

                
            <?php endforeach; }else{ ?>
              <div class="alert alert-danger" role="alert">
                Data tidak ditemukan
              </div>
            <?php
            }
              $total_records = $count_data[0]['jumlah'];
            ?>
            <nav class="mb-5">
                  <ul class="pagination justify-content-center">
                    <?php
                      $jumlah_page = ceil($total_records / $limit);
                      $jumlah_number = 1; //jumlah halaman ke kanan dan kiri dari halaman yang aktif
                      $start_number = ($page > $jumlah_number)? $page - $jumlah_number : 1;
                      $end_number = ($page < ($jumlah_page - $jumlah_number))? $page + $jumlah_number : $jumlah_page;
                      
                      if($page == 1){
                        echo '<li class="page-item disabled"><a class="page-link" href="#">First</a></li>';
                        echo '<li class="page-item disabled"><a class="page-link" href="#"><span aria-hidden="true">&laquo;</span></a></li>';
                      } else {
                        $link_prev = ($page > 1)? $page - 1 : 1;
                        echo '<li class="page-item"><a class="page-link" href="?pages=1">First</a></li>';
                        echo '<li class="page-item"><a class="page-link" href="?pages='.$link_prev.'" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>';
                      }

                      for($i = $start_number; $i <= $end_number; $i++){
                        $link_active = ($page == $i)? ' active' : '';
                        echo '<li class="page-item '.$link_active.'"><a class="page-link" href="?pages='.$i.'">'.$i.'</a></li>';
                      }

                      if($page == $jumlah_page){
                        echo '<li class="page-item disabled"><a class="page-link" href="#"><span aria-hidden="true">&raquo;</span></a></li>';
                        echo '<li class="page-item disabled"><a class="page-link" href="#">Last</a></li>';
                      } else {
                        $link_next = ($page < $jumlah_page)? $page + 1 : $jumlah_page;
                        echo '<li class="page-item"><a class="page-link" href="?pages='.$link_next.'" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>';
                        echo '<li class="page-item"><a class="page-link" href="?pages='.$jumlah_page.'">Last</a></li>';
                      }
                    ?>
                  </ul>
                </nav>
        <?php } ?>
      </div>
    </div>

    <!-- Footer Section -->
    <footer>
      &copy; 2024 22552011198_Irfanka_Hanif_22_Purwakarta
    </footer>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Optional JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script>
      $(document).ready(function () {
    // Real-time validation saat mengetik - hanya menampilkan is-valid
    $('#judul, #deskripsi, #alamat, #telepon').on('input', function () {
        const $input = $(this);
        
        // Remove is-invalid class during input
        $input.removeClass('is-invalid');
        
        // Add is-valid only if there's a value
        if ($input.val().trim() !== '') {
            $input.addClass('is-valid');
        } else {
            $input.removeClass('is-valid');
        }
        
        // Special case for telepon - check format
        if ($input.attr('id') === 'telepon') {
            const teleponRegex = /^[0-9]{10,15}$/;
            if (!teleponRegex.test($input.val())) {
                $input.removeClass('is-valid');
            }
        }
    });

    // Form submit validation - full validation check
    $('#formTambahData').on('submit', function (e) {
        let isValid = true;
        const teleponRegex = /^[0-9]{10,15}$/;
        
        // Reset all validation classes
        const inputs = ['#judul', '#deskripsi', '#alamat', '#telepon'];
        inputs.forEach(input => {
            $(input).removeClass('is-valid is-invalid');
        });

        // Validate each field
        if ($('#judul').val().trim() === '') {
            $('#judul').addClass('is-invalid');
            isValid = false;
        }

        if ($('#deskripsi').val().trim() === '') {
            $('#deskripsi').addClass('is-invalid');
            isValid = false;
        }

        if ($('#alamat').val().trim() === '') {
            $('#alamat').addClass('is-invalid');
            isValid = false;
        }

        if (!teleponRegex.test($('#telepon').val())) {
            $('#telepon').addClass('is-invalid');
            isValid = false;
        }

        if (!isValid) {
            e.preventDefault();
            alert('Silakan lengkapi semua field dengan benar.');
        }
    });
});
    </script>
  </body>
</html>
