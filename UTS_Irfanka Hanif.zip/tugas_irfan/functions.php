<?php

// koneksi ke database
$conn = mysqli_connect("localhost", "root", "", "uts_irfankahanif");


function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}

function tambah($data) {
    global $conn;

    $judul      = $data['judul'];
    $deskripsi  = $data['deskripsi'];
    $alamat     = $data['alamat'];
    $telepon    = $data['telepon'];
    $gambar = upload();
	if( !$gambar ) {
		return false;
	}
    $query = "INSERT INTO tbl_informasi (judul, deskripsi, alamat, telepon, gambar)
              VALUES ('$judul', '$deskripsi', '$alamat', '$telepon', '$gambar')";

    mysqli_query($conn, $query);
    return mysqli_affected_rows($conn);
}

function upload() {
    $namaFile = $_FILES['gambar']['name'];
    $ukuranFile = $_FILES['gambar']['size'];
    $error = $_FILES['gambar']['error'];
    $tmpName = $_FILES['gambar']['tmp_name'];

    if ($error === 4) {
        echo "Pilih gambar terlebih dahulu!";
        return false;
    }

    $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = strtolower(end($ekstensiGambar));
    if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
        echo "Yang Anda upload bukan gambar!";
        return false;
    }

    if ($ukuranFile > 1000000) {
        echo "Ukuran gambar terlalu besar!";
        return false;
    }

    $namaFileBaru = uniqid();
    $namaFileBaru .= '.' . $ekstensiGambar;

    move_uploaded_file($tmpName, 'img/' . $namaFileBaru);
    return $namaFileBaru;
}

function edit($data) {
    global $conn;
    
    // Retrieve data from the form
    $id         = $data['id'];
    $judul      = $data['judul'];
    $deskripsi  = $data['deskripsi'];
    $alamat     = $data['alamat'];
    $telepon    = $data['telepon'];
    $gambarLama = $data['gambarLama'];
    
    // Check if a new image was uploaded, otherwise keep the old image
    if ($_FILES['gambar']['error'] === 4) {
        $gambar = $gambarLama;
    } else {
        $gambar = upload(); // Assuming 'upload' is a function for handling image upload
    }

    // Update the record in the database
    $query = "UPDATE tbl_informasi SET
                judul = '$judul',
                deskripsi = '$deskripsi',
                alamat = '$alamat',
                telepon = '$telepon',
                gambar = '$gambar'
              WHERE id = $id";



    mysqli_query($conn, $query);

    // Return the number of affected rows (1 if updated, 0 if no change)
    return mysqli_affected_rows($conn);
 
}

function hapus($id) {
	global $conn;
    $pilih  = mysqli_query($conn,"SELECT * FROM tbl_informasi WHERE id='$id'");
    $data   = mysqli_fetch_array($pilih);
	$delete = mysqli_query($conn, "DELETE FROM tbl_informasi WHERE id = $id");
    $foto = $data['gambar'];
    unlink('img/'.$foto);
	return mysqli_affected_rows($conn);
}



function registrasi($data) {
	global $conn;

	$nama_lengkap   = strtolower(stripslashes($data["nama_lengkap"]));
	$jk             = strtolower(stripslashes($data["jk"]));
	$alamat         = strtolower(stripslashes($data["alamat"]));
	$email          = strtolower(stripslashes($data["email"]));
	$password       = mysqli_real_escape_string($conn, $data["password"]);

	// Validasi email sudah ada atau belum
    $result = mysqli_query($conn, "SELECT email FROM tbl_user WHERE email = '$email'");
    if (mysqli_fetch_assoc($result)) {
        return "Email sudah terdaftar!";
    }

    // enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);
    // Query untuk menambahkan user baru ke database
    $query = "INSERT INTO tbl_user (nama_lengkap, jenis_kelamin, alamat, email, password) 
              VALUES ('$nama_lengkap', '$jk', '$alamat', '$email', '$password')";

	

	// tambahkan userbaru ke database
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);

}









?>