<?php
if( !isset($_SESSION["login"]) ) {
    header("Location: login.php");
    exit;
}
require 'functions.php';
$id = $_GET['id'];
// query data mahasiswa berdasarkan id
$informasi = query("SELECT * FROM tbl_informasi WHERE id = $id")[0];

?>

<div class="row mt-2">
    <div class="container">
        <div class="row">
            <img class="mx-auto" src="img/<?= $informasi['gambar']; ?>" style="max-width:200px;" alt="">
        </div>
        <div class="row mt-2">
            <center>
                <table class="table table-bordered">
                    <tr>
                        <td>Judul</td>
                        <td><?= $informasi['judul'];?></td>
                    </tr>
                    <tr>
                        <td>Deskripsi</td>
                        <td><?= $informasi['deskripsi'];?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?= $informasi['alamat'];?></td>
                    </tr>
                    <tr>
                        <td>Telepon</td>
                        <td><?= $informasi['telepon'];?></td>
                    </tr>
                </table>
            </center>
        </div>
        
    </div>
</div>

<a href="index.php" class="btn btn-danger">Kembali</a>

